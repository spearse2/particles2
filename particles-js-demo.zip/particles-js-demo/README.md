# particles.js demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/Eric-Dr-Eric-R-Spears-DO-Spears/pen/ZEPqVoq](https://codepen.io/Eric-Dr-Eric-R-Spears-DO-Spears/pen/ZEPqVoq).

Made with particles.js, a lightweight JavaScript library for creating particles